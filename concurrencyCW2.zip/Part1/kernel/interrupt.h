#ifndef __INTERRUPT_H
#define __INTERRUPT_H

//  enable IRQ interrupts
extern void irq_enable();
// disable IRQ interrupts
extern void irq_unable();

#endif
