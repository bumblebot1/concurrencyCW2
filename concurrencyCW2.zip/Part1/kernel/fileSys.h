#ifndef __fileSys_H
#define __fileSys_H

typedef enum {O_CLOSED,O_WR,O_RD,O_RDWR} open_t;

typedef enum {SEEK_L,SEEK_R,SEEK_START,SEEK_END} seek_t;

#endif
